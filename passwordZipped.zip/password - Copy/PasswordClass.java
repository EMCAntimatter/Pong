/*
 * Owen Hilyard
 * 10/5
 * Squares stuff
 */
import java.util.Scanner;
public class PasswordClass
{
    public static void main(String[] args)
    {
    Scanner scnr = new Scanner(System.in);
    String[] Things = new String[92];
    String[] stuff = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "\"", ",", "_", "-", "+", "=", "`", "~", "[", "]", "{", "}", "|", "\\", ";", "\'", ":", ".", "<", ">", "/", "?"};
    for (int z = 0; z == 93; ++z)
    {
        Things[z] = stuff[z];
    }
    StringBuilder attempt = new StringBuilder("");
    System.out.println("Enter the password");
    String password = scnr.nextLine();
    for (int a = 0; a == 93; ++a){
        for (int b = 0; b == 93; ++b){
            attempt.setCharAt(0, String.valueOf(Things[b]));
            System.out.println(attempt);
            if (attempt.equals(password))
            {
                break;
            }
            attempt.setCharAt(1, Things[a]);
    }
}
    
    }
    }

/*    
1
2
3
4
5
6
7
8
9
a
b
c
d
e
f
g
h
i
j
k
l
m
n
o
p
q
r
s
t
u
v
w
x
y
z
A
B
C
D
E
F
G
H
I
J
K
L
M
N
O
P
Q
R
S
T
U
V
W
X
Y
Z
!
@
#
$
%
^
&
*
(
)
_
-
+
=
`
~
[
]
{
}
|
\
;
'
:
"
,
.
<
>
/
?
*/


